<!-- Заявка на подключение -->
<div class="connect-popup popup">
	<div class="connect-popup-dialog popup-dialog">
		<div class="connect-popup-content  popup-content">
			<button class="connect-popup-close popup-close"></button>
				<h5 class="connect-popup-header popup-header">
					Заявка на подключение
				</h5>
				<div class="connect-popup-form popup-form">
					<form action="#">
						<input class="connect-popup-input popup-input" required type="text" name="connect-name" placeholder="Введите имя">
						<input class="connect-popup-input popup-input" required type="number" name="connect-tel" placeholder="Введите телефон">
						<input class="connect-popup-input popup-input" required type="text" name="connect-email" placeholder="Введите Ваш адрес (не обязательно)">
						<button type="submit" class="btn header-connect connect-popup-btn">Заказать звонок</button>						
					</form>
				</div>
		</div>
	</div>
</div>	