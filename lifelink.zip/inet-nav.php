<div class="inet-nav">
	 <ul>
		<li><a href="inet-business.php">Для вашего бизнеса</a></li>
		<li><a href="inet-service.php">Описание услуг</a></li>
		<li><a href="internet.php">Архив товаров</a></li>
	</ul>	
</div>
	 		